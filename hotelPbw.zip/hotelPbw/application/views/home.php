<!DOCTYPE html>
<html>
<head>
	<title>My Website</title>
</head>
<body>
			<h2>Home</h2>
			
			<a href="<?php echo base_url() . 'buzz/readData' ?>"><button>Buzz</button></a>
			<a href="<?php echo base_url() . 'member' ?>"><button>Member</button></a>
			

</body>
</html>