<?php echo "Ini halaman $judul"; ?>
