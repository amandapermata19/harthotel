	<header>Hai <a href="<?php echo base_url('profil') ?>" title="Update profil">
    <?php echo ucfirst($this->session->userdata('username')); ?>
<br>
    <a  href="<?php echo base_url();?>index.php/Login/updateprop/<?php echo $this->session->userdata('id');?>">Update Profile</a>


    </a> | <a href="<?php echo base_url('index.php/Login/logout') ?>" title="Logout">Logout</a></header>