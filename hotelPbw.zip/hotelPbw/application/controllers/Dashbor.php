<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashbor extends CI_Controller {
	
	// Index login
	public function index() {
		
// Proteksi halaman
$this->simple_login->cek_login();

		$data = array(	'title'	=> 'Halaman Dasbor',
						'isi'	=> 'dasbor_view');
		$this->load->view('dashbor_view');
	}
	
	// Fungsi lain
	
}