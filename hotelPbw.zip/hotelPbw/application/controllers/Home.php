<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function __construct() {
	parent::__construct();
	$this->load->model('Buzz_Model');
	$this->load->model('M_register');
	$this->load->library('email');
	}

	public function index()
    {
		$this->load->helper('form');
		$this->load->view('register');
	}

	public function submit(){
		if(isset($_POST['register'])){
		$this->form_validation->set_rules('first_name','first_name','required');

		if ($this->form_validation->run()==TRUE){

		$angka=range(0,9); //code dibuat dari angka 0-9
		shuffle($angka); //untuk mengacak angka
		$ambilangka=array_rand($angka,6); //pengambilan angka sebanyak 6 digit
		$angkastring=implode("",$ambilangka); //membuat angka-angka yang digenerate dipisahkan dengan -
		$code=$angkastring;


		//passing post data dari view
		$this->load->helper(array('form', 'url'));
		$first_name= $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email = $this->input->post('email');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$country = $this->input->post('country');
		$address = $this->input->post('address');
		$city= $this->input->post('city');
		$zipcode= $this->input->post('zipcode');
		
		//memasukan ke array
		$data = array(
			'first_name' => $first_name,
			'last_name' => $last_name,
			'address' => $address,
			'city' => $city,
			'country' => $country,
			'zipcode' => $zipcode,
			'email' => $email,
			'username' => $username,
			'password' => sha1($password),
			'active' => $code
		);

		//tambahkan akun ke database
		
		$id = $this->M_register->add_account($data);
		
		//enkripsi id
		$encrypted_id = md5($id);
		
		$this->load->library('email');
		$this->email->to($email);
		$this->email->from('harthotel@gmail.com','harthotel');
		$this->email->subject('Kode User Anda');
		$this->email->message($code);
		$this->email->send();//untuk pengiriman email

		
		if($this->email->send())
		{
			//echo "Berhasil melakukan registrasi, silahkan cek kode di email kamu";
			//echo $code;
			$this->load->view('berhasil');

		}else
		{
			//echo "Berhasil melakukan registrasi, namu gagal mengirim kode ke email";
			//echo $code;
			$this->load->view('berhasil');
		}
		
		echo "<br><br><a href='".site_url('')."'>Kembali ke Menu UTAMA</a>";}
		
	}


	}
	
	public function verification($key)
	{
		$this->load->helper('url');
		$this->load->model('m_register');
		$this->m_register->changeActiveState($key);
		echo "Selamat kamu telah memverifikasi akun kamu";
		echo "<br><br><a href='".site_url("login")."'>Kembali ke Menu Login</a>";
	}



	function readData() {
		$data = $this->Buzz_Model->getData();
		$this->load->view('Buzz', array('data' => $data));
	}

	function goHomepage(){
    $this->load->view('homepage');

}

  public function event()
	{
		$this->load->view('event');
	}


}
